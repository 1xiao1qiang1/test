$(function () {
    //添加一个模
	$(".h-diy-addModule").click(function () {
        var type = $(this).data("type"); //获取模块类型
        var strUrl = window.location.toLocaleString().toLocaleLowerCase();
        var clientName = "wapshop";
        if (strUrl.replace("/app/", "").length < strUrl.length) {
            clientName = "appshop";
        }

		//默认数据
        var moduleData = {
            id: HiShop.DIY.getTimestamp(), //模块ID
            type: type, //模块类型
            draggable: true, //是否可拖动
            sort: 0, //排序
            content: null //模块内容
        };
		
		//根据模块类型设置默认值
        switch (type) {
            //富文本
            case 1:
                moduleData.ue = null;
                moduleData.content = {
                    fulltext: "&lt;p&gt;『富文本编辑器』&lt;/p&gt;"
                };
                break;
                //标题
        }
		
        //添加模块
        HiShop.DIY.add(moduleData, true);
	})
})